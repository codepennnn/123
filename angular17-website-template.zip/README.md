# Angular 17 Website Template

This is a basic Angular 17 project with Home, About, Contact, Header, and Footer components.